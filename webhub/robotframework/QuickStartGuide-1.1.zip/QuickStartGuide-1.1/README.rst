Robot Framework Quick Start Guide
=================================

*Robot Framework Quick Start Guide* introduces the most important `Robot
Framework <http://robotframework.org>`_ features. You can simply browse
through it and look at the examples, but you can also use the guide as
an executable demo.

The guide itself is in the `<QuickStart.rst>`_ file.
